
import React from 'react';

export const APP_NAME = "MessManager Pro";

export const COLORS = {
  primary: "indigo",
  secondary: "slate",
};

// Start with an empty list as requested. Students will be added upon login.
export const INITIAL_STUDENTS: any[] = [];
