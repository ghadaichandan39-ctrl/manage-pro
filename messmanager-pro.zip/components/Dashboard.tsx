
import React from 'react';
import { Student, StudentMonthlySummary } from '../types';

interface DashboardProps {
  stats: {
    totalSpent: number;
    totalMeals: number;
    mealRate: number;
    studentStats: StudentMonthlySummary[];
  };
  user: Student;
  managerId: string | null;
}

const Dashboard: React.FC<DashboardProps> = ({ stats, user, managerId }) => {
  const managerName = stats.studentStats.find(s => s.studentId === managerId)?.studentName || "Not Assigned";

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Welcome back, {user.name}!</h2>
          <p className="text-slate-500">Current Month status & Billings.</p>
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-indigo-50 border border-indigo-100 rounded-xl">
          <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
             </svg>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider font-bold text-indigo-400">Monthly Manager</p>
            <p className="text-sm font-bold text-indigo-700">{managerName}</p>
          </div>
        </div>
      </header>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500 mb-1">Total Mess Spending</p>
          <p className="text-2xl font-bold text-indigo-600">₹{stats.totalSpent.toLocaleString()}</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500 mb-1">Total Meals Served</p>
          <p className="text-2xl font-bold text-emerald-600">{stats.totalMeals}</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500 mb-1">Cost Per Meal</p>
          <p className="text-2xl font-bold text-amber-600">₹{stats.mealRate.toFixed(2)}</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500 mb-1">Active Students</p>
          <p className="text-2xl font-bold text-slate-900">{stats.studentStats.length}</p>
        </div>
      </div>

      {/* Student List & Calculations */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h3 className="font-bold text-slate-900 text-lg">Student Contributions & Bills</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-600 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4 font-semibold">Student Name</th>
                <th className="px-6 py-4 font-semibold text-center">Meals</th>
                <th className="px-6 py-4 font-semibold text-right">Contributed</th>
                <th className="px-6 py-4 font-semibold text-right">Bill Amount</th>
                <th className="px-6 py-4 font-semibold text-right">Net Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {stats.studentStats.map((item) => (
                <tr key={item.studentId} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-slate-900">
                    {item.studentName}
                    {item.studentId === managerId && (
                      <span className="ml-2 text-[10px] bg-indigo-600 text-white px-1.5 py-0.5 rounded font-bold uppercase">Mgr</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-center text-slate-600">{item.mealsEaten}</td>
                  <td className="px-6 py-4 text-right text-slate-900">₹{item.totalSpent.toLocaleString()}</td>
                  <td className="px-6 py-4 text-right text-indigo-600">₹{item.payableAmount.toFixed(2)}</td>
                  <td className={`px-6 py-4 text-right font-bold ${item.balance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                    {item.balance >= 0 ? '+' : ''}₹{item.balance.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Legend Card */}
      <div className="bg-slate-800 text-white p-6 rounded-2xl">
        <h4 className="font-semibold mb-2">Billing Guide:</h4>
        <ul className="text-sm text-slate-300 space-y-2">
          <li className="flex items-start gap-2">
            <div className="mt-1 w-1.5 h-1.5 rounded-full bg-indigo-400"></div>
            <span><strong>Bill Amount:</strong> Calculated as (Total Eaten Meals × Current Meal Rate).</span>
          </li>
          <li className="flex items-start gap-2">
            <div className="mt-1 w-1.5 h-1.5 rounded-full bg-indigo-400"></div>
            <span><strong>Balance:</strong> (Your Shopping Total) - (Your Bill). Negative means you owe the mess fund.</span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;
