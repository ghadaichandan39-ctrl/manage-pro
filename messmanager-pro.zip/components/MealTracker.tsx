
import React, { useState } from 'react';
import { MealRecord, Student } from '../types';

interface MealTrackerProps {
  records: MealRecord[];
  setRecords: React.Dispatch<React.SetStateAction<MealRecord[]>>;
  students: Student[];
}

const MealTracker: React.FC<MealTrackerProps> = ({ records, setRecords, students }) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const toggleMeal = (studentId: string, currentCount: number) => {
    const nextCount = currentCount === 3 ? 0 : currentCount + 1; // Cycle 0 -> 1 -> 2 -> 3 (Breakfast, Lunch, Dinner)
    
    setRecords(prev => {
      const filtered = prev.filter(r => !(r.studentId === studentId && r.date === selectedDate));
      if (nextCount === 0) return filtered;
      
      const newRecord: MealRecord = {
        id: `${studentId}-${selectedDate}`,
        studentId,
        date: selectedDate,
        mealCount: nextCount
      };
      return [...filtered, newRecord];
    });
  };

  const getMealCount = (studentId: string) => {
    return records.find(r => r.studentId === studentId && r.date === selectedDate)?.mealCount || 0;
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Daily Meal Tracking</h2>
          <p className="text-slate-500">Record how many meals each student ate on a specific day.</p>
        </div>
        <input
          type="date"
          className="px-4 py-2 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
        />
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {students.map((student) => {
          const count = getMealCount(student.id);
          return (
            <div key={student.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between items-center text-center gap-4">
              <div>
                <h3 className="font-bold text-lg text-slate-900">{student.name}</h3>
                <p className="text-xs text-slate-500">{student.mobile}</p>
              </div>
              
              <div className="flex items-center gap-2">
                {[1, 2, 3].map((num) => (
                  <div 
                    key={num}
                    className={`w-3 h-3 rounded-full ${count >= num ? 'bg-indigo-600' : 'bg-slate-100'}`}
                  />
                ))}
              </div>

              <div className="w-full flex gap-2">
                <button
                  onClick={() => toggleMeal(student.id, count)}
                  className={`flex-1 py-3 px-4 rounded-xl font-medium transition-all ${
                    count === 0 ? 'bg-slate-100 text-slate-600 hover:bg-indigo-100' : 
                    count === 3 ? 'bg-indigo-600 text-white' : 'bg-indigo-100 text-indigo-700'
                  }`}
                >
                  {count === 0 ? 'None' : count === 1 ? '1 Meal' : count === 2 ? '2 Meals' : '3 Meals'}
                </button>
              </div>
              <p className="text-[10px] text-slate-400">Click button to cycle meal count (0-3)</p>
            </div>
          );
        })}
      </div>

      <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl text-amber-800 text-sm flex gap-3">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 shrink-0" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
        </svg>
        <p>Record 1 for breakfast/brunch, 2 for half-day, or 3 for full three meals. This data is used to calculate individual bills based on consumption.</p>
      </div>
    </div>
  );
};

export default MealTracker;
